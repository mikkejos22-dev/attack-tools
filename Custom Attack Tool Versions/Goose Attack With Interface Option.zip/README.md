# attack_tool_web
Combined attack toolkit with WebUI for several scenarios:
1. PLC Light tower demokit: MOXA ioLogik E2214
2. PLC Conveyor demokit: Mitsubishi Q series PLC
3. IED: ABB REF620 & RED 670
4. SCADA: Unpatched Windows 7 machine

Created using Python 3.7 with Flask, PyQT5, Scapy, pymodbus, etc.
Tested under Windows 10, Chrome.
